import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class CustomTextfield extends StatelessWidget {
  const CustomTextfield({
    super.key,
    required this.hintText,
    this.controller,
    this.validator,
    this.keyboardType,
    this.onTap,
    this.inputFormatters,
    this.readOnly,
    TextStyle? hintStyle, this.suffixIcon, this.obscureText, this.prefixIcon, this.filled, this.color,
  });
  final String hintText;
  final TextEditingController? controller;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final VoidCallback? onTap;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final List<TextInputFormatter>? inputFormatters;
  final bool? readOnly;
  final bool? obscureText;
  final bool? filled;
  final Color? color;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      obscureText: obscureText??false,
      // style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
      controller: controller,
      validator: validator,
      keyboardType: keyboardType,
      onTap: onTap,
      inputFormatters: inputFormatters,
      readOnly: readOnly ?? false,
      decoration: InputDecoration(
          filled: filled??false,
          fillColor: color,
          contentPadding: const EdgeInsets.all(15),
          // focusedErrorBorder: const UnderlineInputBorder(borderSide: BorderSide(color: AppColors.blackColor)),
          // errorBorder: const UnderlineInputBorder(borderSide: BorderSide(color: AppColors.blackColor)),
          focusedBorder:  OutlineInputBorder(borderSide: const BorderSide(color: Colors.grey,width: 2),borderRadius: BorderRadius.circular(5)),
          // enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: AppColors.blackColor)),
          hintText: hintText,
          hintStyle: const TextStyle(color: Colors.grey),
          suffixIcon: suffixIcon,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(5), borderSide: const BorderSide(color: Colors.grey, width: 2))),
    );
  }
}
