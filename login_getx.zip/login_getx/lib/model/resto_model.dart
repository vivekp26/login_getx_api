class RestoModel {
  int? code;
  String? msg;
  String? restaurantOnOff;
  List<Result>? result;
  Bravges? bravges;
  RestaurantDetails? restaurantDetails;

  RestoModel({this.code, this.msg, this.restaurantOnOff, this.result, this.bravges, this.restaurantDetails});

  RestoModel.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    msg = json['msg'];
    restaurantOnOff = json['restaurant_on_off'];
    if (json['Result'] != null) {
      result = <Result>[];
      json['Result'].forEach((v) { result!.add(new Result.fromJson(v)); });
    }
    bravges = json['Bravges'] != null ? new Bravges.fromJson(json['Bravges']) : null;
    restaurantDetails = json['restaurant_details'] != null ? new RestaurantDetails.fromJson(json['restaurant_details']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['msg'] = this.msg;
    data['restaurant_on_off'] = this.restaurantOnOff;
    if (this.result != null) {
      data['Result'] = this.result!.map((v) => v.toJson()).toList();
    }
    if (this.bravges != null) {
      data['Bravges'] = this.bravges!.toJson();
    }
    if (this.restaurantDetails != null) {
      data['restaurant_details'] = this.restaurantDetails!.toJson();
    }
    return data;
  }
}

class Result {
  int? restaurantMenuId;
  int? restaurantId;
  String? colorCode;
  String? isBogo;
  String? menuName;
  String? name;
  String? menuDescription;
  String? isDisplayImage;
  String? menuImage;
  String? image;
  int? itemCounts;
  List<MenuItemDetail>? menuItemDetail;

  Result({this.restaurantMenuId, this.restaurantId, this.colorCode, this.isBogo, this.menuName, this.name, this.menuDescription, this.isDisplayImage, this.menuImage, this.image, this.itemCounts, this.menuItemDetail});

  Result.fromJson(Map<String, dynamic> json) {
    restaurantMenuId = json['restaurant_menu_id'];
    restaurantId = json['restaurant_id'];
    colorCode = json['color_code'];
    isBogo = json['is_bogo'];
    menuName = json['menu_name'];
    name = json['name'];
    menuDescription = json['menu_description'];
    isDisplayImage = json['is_display_image'];
    menuImage = json['menu_image'];
    image = json['image'];
    itemCounts = json['item_counts'];
    if (json['menu_item_detail'] != null) {
      menuItemDetail = <MenuItemDetail>[];
      json['menu_item_detail'].forEach((v) { menuItemDetail!.add(new MenuItemDetail.fromJson(v)); });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['restaurant_menu_id'] = restaurantMenuId;
    data['restaurant_id'] = restaurantId;
    data['color_code'] = colorCode;
    data['is_bogo'] = isBogo;
    data['menu_name'] = menuName;
    data['name'] = name;
    data['menu_description'] = menuDescription;
    data['is_display_image'] = isDisplayImage;
    data['menu_image'] = menuImage;
    data['image'] = image;
    data['item_counts'] = itemCounts;
    if (this.menuItemDetail != null) {
      data['menu_item_detail'] = menuItemDetail!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class MenuItemDetail {
  int? restaurantId;
  String? itemId;
  String? isFeatured;
  String? isBogo;
  String? itemName;
  String? itemDescription;
  String? image;
  List<ItemImages>? itemImages;
  int? itemTax;
  List<dynamic>? customDetails;
  int? quantity;
  String? timeSlot;
  String? isSoldOut;
  dynamic mrp;
  dynamic  price;
  String? isAlcoholic;
  String? itemType;
  String? itemPackagingCharge;
  int? isCustomization;
  List<ItemTags>? itemTags;
  int? isItemSubscribe;

  MenuItemDetail({this.restaurantId, this.itemId, this.isFeatured, this.isBogo, this.itemName, this.itemDescription, this.image, this.itemImages, this.itemTax, this.customDetails, this.quantity, this.timeSlot, this.isSoldOut, this.mrp, this.price, this.isAlcoholic, this.itemType, this.itemPackagingCharge, this.isCustomization, this.itemTags, this.isItemSubscribe});

  MenuItemDetail.fromJson(Map<String, dynamic> json) {
    restaurantId = json['restaurant_id'];
    itemId = json['item_id'];
    isFeatured = json['is_featured'];
    isBogo = json['is_bogo'];
    itemName = json['item_name'];
    itemDescription = json['item_description'];
    image = json['image'];
    if (json['item_images'] != null) {
      itemImages = <ItemImages>[];
      json['item_images'].forEach((v) { itemImages!.add(new ItemImages.fromJson(v)); });
    }
    itemTax = json['item_tax'];
    customDetails = json['custom_details'];
    quantity = json['quantity'];
    timeSlot = json['time_slot'];
    isSoldOut = json['is_sold_out'];
    mrp = json['mrp'];
    price = json['price'];
    isAlcoholic = json['is_alcoholic'];
    itemType = json['item_type'];
    itemPackagingCharge = json['item_packaging_charge'];
    isCustomization = json['is_customization'];
    if (json['item_tags'] != null) {
      itemTags = <ItemTags>[];
      json['item_tags'].forEach((v) { itemTags!.add(new ItemTags.fromJson(v)); });
    }
    isItemSubscribe = json['is_item_subscribe'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['restaurant_id'] = this.restaurantId;
    data['item_id'] = this.itemId;
    data['is_featured'] = this.isFeatured;
    data['is_bogo'] = this.isBogo;
    data['item_name'] = this.itemName;
    data['item_description'] = this.itemDescription;
    data['image'] = this.image;
    if (this.itemImages != null) {
      data['item_images'] = this.itemImages!.map((v) => v.toJson()).toList();
    }
    data['item_tax'] = this.itemTax;
    if (this.customDetails != null) {
      data['custom_details'] = this.customDetails!.map((v) => v.toJson()).toList();
    }
    data['quantity'] = this.quantity;
    data['time_slot'] = this.timeSlot;
    data['is_sold_out'] = this.isSoldOut;
    data['mrp'] = this.mrp;
    data['price'] = this.price;
    data['is_alcoholic'] = this.isAlcoholic;
    data['item_type'] = this.itemType;
    data['item_packaging_charge'] = this.itemPackagingCharge;
    data['is_customization'] = this.isCustomization;
    if (this.itemTags != null) {
      data['item_tags'] = this.itemTags!.map((v) => v.toJson()).toList();
    }
    data['is_item_subscribe'] = this.isItemSubscribe;
    return data;
  }
}

class ItemImages {
  String? imageName;

  ItemImages({this.imageName});

  ItemImages.fromJson(Map<String, dynamic> json) {
    imageName = json['image_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['image_name'] = this.imageName;
    return data;
  }
}

class ItemTags {
  int? id;
  String? name;
  String? secondaryName;
  String? textColor;
  String? backgroundColor;

  ItemTags({this.id, this.name, this.secondaryName, this.textColor, this.backgroundColor});

  ItemTags.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    secondaryName = json['secondary_name'];
    textColor = json['text_color'];
    backgroundColor = json['background_color'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['secondary_name'] = this.secondaryName;
    data['text_color'] = this.textColor;
    data['background_color'] = this.backgroundColor;
    return data;
  }
}

class Bravges {


  Bravges();

  Bravges.fromJson(Map<String, dynamic> json) {
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    return data;
  }
}
class RestaurantTags {
  int? id;
  String? name;

  RestaurantTags({this.id, this.name});

  RestaurantTags.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
    };
  }
}

class RestaurantDetails {
  int? restaurantId;
  String? slug;
  String? name;
  String? restaurantAddress;
  String? nameThai;
  int? restaurantTax;
  String? addressThai;
  String? restaurantItemLayout;
  String? email;
  String? fssaiLicence;
  String? locationAddress;
  String? deliveryTime;
  Null? isSameDayDelivery;
  int? minimumOrderValue;
  String? timeSlots;
  String? twoPersonPrice;
  int? deliveryChargeOld;
  String? serviceFee;
  String? latitude;
  String? longitude;
  String? iconImage;
  String? paymentOption;
  String? deliveryTypeTimeSlots;
  String? avgRating;
  String? appDetailLayout;
  String? restaurantPackagingType;
  String? restaurantPackagingCharge;
  String? restaurantConvinceType;
  int? restaurantConvinceCharge;
  String? isPreOrder;
  int? preOrderTime;
  String? isPreOrderType;
  String? showCustomerApp;
  int? minimumAdminCommision;
  String? adminCommisionType;
  int? adminCommision;
  String? address;
  int? itemCounts;
  String? discountText;
  int? menuCategoryCount;
  String? businessLicenceNumber;
  String? fullAddress;
  int? restaurantServiceTax;
  String? deliveryCharge;
  String? sGST;
  String? cGST;
  double? rating;
  int? reviewCount;
  String? restaurantOnOff;
  List<String>? cuisineName;
  List<RestaurantTags>? restaurantTags;

  RestaurantDetails({this.restaurantId, this.slug, this.name, this.restaurantAddress, this.nameThai, this.restaurantTax, this.addressThai, this.restaurantItemLayout, this.email, this.fssaiLicence, this.locationAddress, this.deliveryTime, this.isSameDayDelivery, this.minimumOrderValue, this.timeSlots, this.twoPersonPrice, this.deliveryChargeOld, this.serviceFee, this.latitude, this.longitude, this.iconImage, this.paymentOption, this.deliveryTypeTimeSlots, this.avgRating, this.appDetailLayout, this.restaurantPackagingType, this.restaurantPackagingCharge, this.restaurantConvinceType, this.restaurantConvinceCharge, this.isPreOrder, this.preOrderTime, this.isPreOrderType, this.showCustomerApp, this.minimumAdminCommision, this.adminCommisionType, this.adminCommision, this.address, this.itemCounts, this.discountText, this.menuCategoryCount, this.businessLicenceNumber, this.fullAddress, this.restaurantServiceTax, this.deliveryCharge, this.sGST, this.cGST, this.rating, this.reviewCount, this.restaurantOnOff, this.cuisineName, this.restaurantTags});

  RestaurantDetails.fromJson(Map<String, dynamic> json) {
    restaurantId = json['restaurant_id'];
    slug = json['slug'];
    name = json['name'];
    restaurantAddress = json['restaurant_address'];
    nameThai = json['name_thai'];
    restaurantTax = json['restaurant_tax'];
    addressThai = json['address_thai'];
    restaurantItemLayout = json['restaurant_item_layout'];
    email = json['email'];
    fssaiLicence = json['fssai_licence'];
    locationAddress = json['location_address'];
    deliveryTime = json['delivery_time'];
    isSameDayDelivery = json['is_same_day_delivery'];
    minimumOrderValue = json['minimum_order_value'];
    timeSlots = json['time_slots'];
    twoPersonPrice = json['two_person_price'];
    deliveryChargeOld = json['delivery_charge_old'];
    serviceFee = json['service_fee'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    iconImage = json['icon_image'];
    paymentOption = json['payment_option'];
    deliveryTypeTimeSlots = json['delivery_type_time_slots'];
    avgRating = json['avg_rating'];
    appDetailLayout = json['app_detail_layout'];
    restaurantPackagingType = json['restaurant_packaging_type'];
    restaurantPackagingCharge = json['restaurant_packaging_charge'];
    restaurantConvinceType = json['restaurant_convince_type'];
    restaurantConvinceCharge = json['restaurant_convince_charge'];
    isPreOrder = json['is_pre_order'];
    preOrderTime = json['pre_order_time'];
    isPreOrderType = json['is_pre_order_type'];
    showCustomerApp = json['show_customer_app'];
    minimumAdminCommision = json['minimum_admin_commision'];
    adminCommisionType = json['admin_commision_type'];
    adminCommision = json['admin_commision'];
    address = json['Address'];
    itemCounts = json['item_counts'];
    discountText = json['discount_text'];
    menuCategoryCount = json['menu_category_count'];
    businessLicenceNumber = json['business_licence_number'];
    fullAddress = json['full_address'];
    restaurantServiceTax = json['restaurant_service_tax'];
    deliveryCharge = json['delivery_charge'];
    sGST = json['SGST'];
    cGST = json['CGST'];
    rating = json['rating'];
    reviewCount = json['review_count'];
    restaurantOnOff = json['restaurant_on_off'];

    if (json['restaurant_tags'] != null) {
      restaurantTags = (json['restaurant_tags']as List).map((v) => RestaurantTags.fromJson(v))
          .toList();;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['restaurant_id'] = this.restaurantId;
    data['slug'] = this.slug;
    data['name'] = this.name;
    data['restaurant_address'] = this.restaurantAddress;
    data['name_thai'] = this.nameThai;
    data['restaurant_tax'] = this.restaurantTax;
    data['address_thai'] = this.addressThai;
    data['restaurant_item_layout'] = this.restaurantItemLayout;
    data['email'] = this.email;
    data['fssai_licence'] = this.fssaiLicence;
    data['location_address'] = this.locationAddress;
    data['delivery_time'] = this.deliveryTime;
    data['is_same_day_delivery'] = this.isSameDayDelivery;
    data['minimum_order_value'] = this.minimumOrderValue;
    data['time_slots'] = this.timeSlots;
    data['two_person_price'] = this.twoPersonPrice;
    data['delivery_charge_old'] = this.deliveryChargeOld;
    data['service_fee'] = this.serviceFee;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['icon_image'] = this.iconImage;
    data['payment_option'] = this.paymentOption;
    data['delivery_type_time_slots'] = this.deliveryTypeTimeSlots;
    data['avg_rating'] = this.avgRating;
    data['app_detail_layout'] = this.appDetailLayout;
    data['restaurant_packaging_type'] = this.restaurantPackagingType;
    data['restaurant_packaging_charge'] = this.restaurantPackagingCharge;
    data['restaurant_convince_type'] = this.restaurantConvinceType;
    data['restaurant_convince_charge'] = this.restaurantConvinceCharge;
    data['is_pre_order'] = this.isPreOrder;
    data['pre_order_time'] = this.preOrderTime;
    data['is_pre_order_type'] = this.isPreOrderType;
    data['show_customer_app'] = this.showCustomerApp;
    data['minimum_admin_commision'] = this.minimumAdminCommision;
    data['admin_commision_type'] = this.adminCommisionType;
    data['admin_commision'] = this.adminCommision;
    data['Address'] = this.address;
    data['item_counts'] = this.itemCounts;
    data['discount_text'] = this.discountText;
    data['menu_category_count'] = this.menuCategoryCount;
    data['business_licence_number'] = this.businessLicenceNumber;
    data['full_address'] = this.fullAddress;
    data['restaurant_service_tax'] = this.restaurantServiceTax;
    data['delivery_charge'] = this.deliveryCharge;
    data['SGST'] = this.sGST;
    data['CGST'] = this.cGST;
    data['rating'] = this.rating;
    data['review_count'] = this.reviewCount;
    data['restaurant_on_off'] = this.restaurantOnOff;
    data['cuisine_name'] = this.cuisineName;
    if (this.restaurantTags != null) {
      data['restaurant_tags'] = this.restaurantTags!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}




