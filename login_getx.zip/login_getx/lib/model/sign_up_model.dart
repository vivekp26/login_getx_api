class SignUpModel {
  int? code;
  String? msg;
  int? newUserId;
  UserDetails? userDetails;

  SignUpModel({this.code, this.msg, this.newUserId, this.userDetails});

  SignUpModel.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    msg = json['msg'];
    newUserId = json['new_user_id'];
    userDetails = json['user_details'] != null
        ? new UserDetails.fromJson(json['user_details'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['msg'] = this.msg;
    data['new_user_id'] = this.newUserId;
    if (this.userDetails != null) {
      data['user_details'] = this.userDetails!.toJson();
    }
    return data;
  }
}

class UserDetails {
  int? userId;
  String? referralCode;
  String? userRole;
  String? mobileNumber;
  String? countryCode;
  String? userName;
  String? lastName;
  String? userEmail;
  String? isLanguage;
  String? userProfile;
  String? verifyAlcoholImage;
  String? alcoholStatus;
  String? userNotificationSound;
  String? status;
  int? isCodEnable;
  String? walletStatus;
  int? isTestUser;
  String? isAppleLogin;
  String? devicetoken;
  int? walletAmount;
  String? customise;
  String? walletRechargeLimit;
  String? maximumWalletAmount;
  String? token;
  String? wallet;

  UserDetails(
      {this.userId,
        this.referralCode,
        this.userRole,
        this.mobileNumber,
        this.countryCode,
        this.userName,
        this.lastName,
        this.userEmail,
        this.isLanguage,
        this.userProfile,
        this.verifyAlcoholImage,
        this.alcoholStatus,
        this.userNotificationSound,
        this.status,
        this.isCodEnable,
        this.walletStatus,
        this.isTestUser,
        this.isAppleLogin,
        this.devicetoken,
        this.walletAmount,
        this.customise,
        this.walletRechargeLimit,
        this.maximumWalletAmount,
        this.token,
        this.wallet});

  UserDetails.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    referralCode = json['referral_code'];
    userRole = json['user_role'];
    mobileNumber = json['mobile_number'];
    countryCode = json['country_code'];
    userName = json['user_name'];
    lastName = json['last_name'];
    userEmail = json['user_email'];
    isLanguage = json['is_language'];
    userProfile = json['user_profile'];
    verifyAlcoholImage = json['verify_alcohol_image'];
    alcoholStatus = json['alcohol_status'];
    userNotificationSound = json['user_notification_sound'];
    status = json['status'];
    isCodEnable = json['is_cod_enable'];
    walletStatus = json['wallet_status'];
    isTestUser = json['is_test_user'];
    isAppleLogin = json['is_apple_login'];
    devicetoken = json['devicetoken'];
    walletAmount = json['wallet_amount'];
    customise = json['customise'];
    walletRechargeLimit = json['wallet_recharge_limit'];
    maximumWalletAmount = json['maximum_wallet_amount'];
    token = json['token'];
    wallet = json['wallet'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['referral_code'] = this.referralCode;
    data['user_role'] = this.userRole;
    data['mobile_number'] = this.mobileNumber;
    data['country_code'] = this.countryCode;
    data['user_name'] = this.userName;
    data['last_name'] = this.lastName;
    data['user_email'] = this.userEmail;
    data['is_language'] = this.isLanguage;
    data['user_profile'] = this.userProfile;
    data['verify_alcohol_image'] = this.verifyAlcoholImage;
    data['alcohol_status'] = this.alcoholStatus;
    data['user_notification_sound'] = this.userNotificationSound;
    data['status'] = this.status;
    data['is_cod_enable'] = this.isCodEnable;
    data['wallet_status'] = this.walletStatus;
    data['is_test_user'] = this.isTestUser;
    data['is_apple_login'] = this.isAppleLogin;
    data['devicetoken'] = this.devicetoken;
    data['wallet_amount'] = this.walletAmount;
    data['customise'] = this.customise;
    data['wallet_recharge_limit'] = this.walletRechargeLimit;
    data['maximum_wallet_amount'] = this.maximumWalletAmount;
    data['token'] = this.token;
    data['wallet'] = this.wallet;
    return data;
  }
}
