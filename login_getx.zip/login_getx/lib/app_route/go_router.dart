import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:login_getx/auth_screens/login_screen.dart';
import 'package:login_getx/auth_screens/sign_up_screen.dart';
import 'package:login_getx/home_page.dart';

class RoutesClas{
  static String home = "/";
  static String login = "/login";
  static String signUp = "/signUp";

  static String getHomeRoute()=>home;
  static String getLoginRoute()=> login;
  static String getSignUpRoute()=> signUp;

static  List<GetPage> routes = [
    GetPage(
        name: home,
        page: () => const HomePage(),
    ),
  GetPage(
    name: login,
    page: () => const LoginScreen(),
  ),
  GetPage(
    name: signUp,
    page: () => const SignUpScreen(),
  ),

  ];
}
