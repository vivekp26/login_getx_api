import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:login_getx/app_route/go_router.dart';
import 'package:login_getx/auth_screens/login_screen.dart';
import 'package:login_getx/model/sign_up_model.dart';

class SignUpController extends GetxController {
  final emailController = TextEditingController().obs;
  final passwordController = TextEditingController().obs;
  final phoneController = TextEditingController().obs;
  final nameController = TextEditingController().obs;
  RxBool isLoading = false.obs;

  void signUpApi() async {
    isLoading.value = true;
    try {
      final response = await http.post(
        Uri.parse('https://api.deonde.co/api/v2/registration'),
        body: {
          'vendor_id': '42148',
          'email': emailController.value.text,
          'user_name': nameController.value.text,
          'mobile_number': phoneController.value.text,
          'password': passwordController.value.text,
          'time_zone': '+5:30',
          'os': '11',
          'device_model': 'SM-A505F',
          'app_version': '1',
          'devicetype': 'A',
        },
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        print(response.statusCode);
        print(data);
        final newResponse = SignUpModel.fromJson(data);
        Fluttertoast.showToast(msg: '${newResponse.msg}');
        Get.snackbar('User Created Successful', 'Sucessfull');
        // Get.off(LoginScreen());
        Get.offNamed(RoutesClas.getLoginRoute());
      } else {
        Get.snackbar('Something went wrong', 'error');
        isLoading.value = false;
      }
    } on Exception catch (e) {
      Get.snackbar('Exception Error:', e.toString());
      isLoading.value = false;
      // TODO
    } finally {
      isLoading.value = false;
    }
  }
}
