import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart'as http;
import 'package:login_getx/model/resto_model.dart';

class RestoCategoryController extends GetxController{
  RxBool isLoading = false.obs;
  RxList<Result> resultList = RxList<Result>();

  Future<void> restoApi()async{
    isLoading.value=true;
    try {
      final response = await http.post(Uri.parse('https://dev.deonde.co/deondeapi/api/v2/restaurantcategorymenus'),
      body: {
        'vendor_id': '40818',
        'restaurant_id': '4079',
      }
      );

      if(response.statusCode==200){
        var data = jsonDecode(response.body);
        print(response.statusCode);
        print(data);
        final newResponse = RestoModel.fromJson(data);
        resultList.value = newResponse.result?.map((result)=> result).toList()??[];
        Get.snackbar('Restuarent Menus', 'Choose your Food',colorText: Colors.black);
      }else{
        Get.snackbar('Something went wrong', 'Failed');
        isLoading.value = false;
      }
    } on Exception catch (e) {
      Get.snackbar('Exception Error', e.toString());
      isLoading.value = false;
      // TODO
    }
  }
}