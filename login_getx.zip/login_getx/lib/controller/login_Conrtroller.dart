import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:login_getx/app_route/go_router.dart';
import 'package:login_getx/home_page.dart';

class LoginController extends GetxController {
  RxBool isLoading = false.obs;

  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  void loginApi() async {
    isLoading.value = true;
    try {
      final response = await http.post(Uri.parse('https://api.deonde.co/api/v2/login'), body: {
        'vendor_id': '42148',
        'email': emailController.text.trim(),
        'password': passwordController.text.trim(),
      });
      var data = jsonDecode(response.body);
      print(response.statusCode);
      print(data);
      if (response.statusCode == 200) {
        Get.snackbar('Login Successful', 'Sucessfull');
        // Get.offAll(() => HomePage());
        Get.offAllNamed(RoutesClas.getHomeRoute());
      } else {
        Get.snackbar('Login Failed', 'error');
        isLoading.value = false;
      }
    } on Exception catch (e) {
      Get.snackbar('Exception', e.toString());
      isLoading.value = false;
      // TODO
    } finally {
      isLoading.value = false;
    }
  }

  void clearFields() {
    emailController.clear();
    passwordController.clear();
  }

  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    super.onClose();
  }
}
