import 'dart:convert';
import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:login_getx/common/shared_prf.dart';


class ApiManager {
  Dio dio = Dio();
  static final _singleton = ApiManager.instance;
  static ApiManager get instance => _singleton;

  Future postResponse({required String endPoints,
    dynamic request,
    Map<String, dynamic>? headers,
    Encoding? encoding,
    CancelToken? cancelToken}) async {
    try {
      final innerHeader = await getHeaders();
      _loggerCurl(method: 'POST', url: endPoints, headers: innerHeader, queryParameters: request);

      log("Headers => ${headers ?? innerHeader}");
      log("Request ${request.toString()}");
      log("Url $endPoints");
      final response = await dio.post(
        endPoints,
        data: request,
        cancelToken: cancelToken,
        options: Options(receiveTimeout: const Duration(minutes: 1), headers: headers ?? innerHeader, method: 'POST'),
      );
      if (response.statusCode == 200) {
        return response.data;
      } else {
        if (response.statusCode == 503) {
          //  AppNavigations.goToMaintenanceModeAndRemoveAll();
        }
      }
    } catch (statusCode) {
      if (statusCode.toString().contains('503')) {
        // if (Get.currentRoute != Routes.maintenanceMode) {
        //   AppNavigations.goToMaintenanceModeAndRemoveAll();
        // }
        throw ('Maintaince Mode On : $statusCode');
      } else {
        //    await SharedPrefs.removeUserData();
        // AppNavigations.goToSignUpScreenAndRemoveAll();
        if (statusCode == 400) {
          throw ('BadRequestException: ${statusCode.toString()}');
        } else if (statusCode == 401 || statusCode == 403) {
          throw ('Unautoraized Exception : ${statusCode.toString()}');
        } else if (statusCode == 404) {
          throw ('Not found');
        } else if (statusCode == 500) {
          throw ('Internal Server Error');
        } else {
          throw ('Error occurred while Communication with Server with StatusCode : $statusCode');
        }
      }
    }
  }

}

void _loggerCurl({
  required String method,
  required String url,
  required Map<String, String>? headers,
  required Map<String, dynamic>? queryParameters,
}) {
  StringBuffer curlCommand = StringBuffer('curl -X $method "$url"');

  // Add headers
  if (headers != null) {
    headers.forEach((key, value) {
      curlCommand.write(' -H "$key: $value"');
    });
  }}
Future<Map<String, String>> getHeaders() async {
  final user = await SharedPrefs.getUser();

  if (user != null && user['token'] != null && user['token'].isNotEmpty) {
    return {
      "Content-Type": "application/json",
      "Authorization": "Bearer ${user['token']}",
    };
  } else {
    return {
      "Content-Type": "application/json",
    };
  }
}

