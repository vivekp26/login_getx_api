import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:login_getx/controller/signUp_controller.dart';
import 'package:login_getx/model/custom_textfield.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final SignUpController _signupContObj = Get.put(SignUpController());
  RxBool isVisible = false.obs;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Finish Your Profile',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  CustomTextfield(
                    validator: (value) {
                      if (value?.isEmpty ?? false) {
                        return 'Enter UserName';
                      }
                    },
                    controller: _signupContObj.nameController.value,
                    hintText: 'Enter Full Name',
                    hintStyle: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CustomTextfield(
                    hintText: 'Enter Email',
                    controller: _signupContObj.emailController.value,
                    validator: (value) {
                      bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                      if (value.isEmpty) {
                        return 'Enter Email';
                      }
                      if (!emailValid) {
                        return 'Enter Valid Email';
                      }
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Obx(() {
                    return CustomTextfield(
                      obscureText: !isVisible.value,
                      hintText: 'Enter Password',
                      controller: _signupContObj.passwordController.value,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter Password';
                        } else if (_signupContObj.passwordController.value.text.length < 6) {
                          return 'Password Length must not be less than 6';
                        }
                      },
                      suffixIcon: IconButton(
                          onPressed: () {
                            isVisible.value = !isVisible.value;
                          },
                          icon: Icon(
                            isVisible.value ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                            size: 25,
                          )),
                    );
                  }),
                  const SizedBox(
                    height: 20,
                  ),
                  IntlPhoneField(
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    controller: _signupContObj.phoneController.value,
                    decoration: InputDecoration(
                      focusedBorder:
                          OutlineInputBorder(borderSide: const BorderSide(color: Colors.grey, width: 2), borderRadius: BorderRadius.circular(5)),
                      hintText: 'Enter your Mobile Number',
                      hintStyle: const TextStyle(color: Colors.grey),
                      border: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey, width: 2),
                      ),
                    ),
                    initialCountryCode: 'IN',
                    onChanged: (phone) {
                      print(phone.completeNumber);
                    },
                  ),
                  const Text(
                    'By doing Signup, you agree with all Terms& Conditions of Deonde',
                    style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 300,
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Obx(() {
                      return InkWell(
                        onTap: () {
                                if (_formKey.currentState?.validate() ?? false) {
                                  _signupContObj.signUpApi();
                                }
                              },
                        child:Container(
                                constraints: const BoxConstraints(minHeight: 60),
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), color: Colors.blue.shade900),
                                child:  _signupContObj.isLoading.value
                                    ? Center(child: const CircularProgressIndicator())
                                    : Center(
                                    child: Text(
                                  'Sign Up',
                                  style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                                )),
                              ),
                      );
                    }),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
