import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login_getx/home_page.dart';
import 'package:login_getx/controller/login_Conrtroller.dart';
import 'package:login_getx/model/custom_textfield.dart';
import 'package:login_getx/auth_screens/sign_up_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController logincontObj = Get.put(LoginController());
  final RxBool isVisible = false.obs;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _checkLoginStatus();
  }

  @override
  void dispose() {
    logincontObj.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  Future<void> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    if (isLoggedIn) {
      Get.off(() => HomePage());
    }
  }

  Future<void> _saveLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', true); // Save login status as true
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/MMilk.jpg',
                    height: 100,
                    width: 100,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const Text(
                    'Milk Delivery',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  const Text(
                    'login to your account to manage orders',
                    style: TextStyle(fontSize: 18, color: Colors.grey, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomTextfield(
                    controller: logincontObj.emailController,
                    hintText: 'Enter Email',
                    validator: (value) {
                      bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                      if (value.isEmpty) {
                        return 'Enter Email';
                      }
                      if (!emailValid) {
                        return 'Enter Valid Email';
                      }
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Obx(() {
                    return CustomTextfield(
                      controller: logincontObj.passwordController,
                      obscureText: !isVisible.value,
                      hintText: 'Enter Password',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter Password';
                        }
                      },
                      suffixIcon: IconButton(
                          onPressed: () {
                            isVisible.value = !isVisible.value;
                          },
                          icon: Icon(
                            isVisible.value ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                            size: 25,
                          )),
                    );
                  }),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        TextButton(
                            onPressed: () {
                              Get.to(() => const SignUpScreen());
                            },
                            child: const Text('SignUp now')),
                        TextButton(onPressed: () {}, child: const Text('Forgot Password')),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 250,
                  ),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: logincontObj.isLoading.value
                          ? const CircularProgressIndicator()
                          : Obx(() {
                              return InkWell(
                                onTap: () {
                                  if (_formKey.currentState?.validate() ?? false) {
                                    _saveLoginStatus();
                                    logincontObj.loginApi();
                                  }
                                },
                                child:  Container(
                                        constraints: const BoxConstraints(maxHeight: 60),
                                        width: MediaQuery.of(context).size.width,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(30),
                                          color: Colors.blue.shade900,
                                        ),
                                        child:logincontObj.isLoading.value
                                            ? const Center(child: const CircularProgressIndicator(color: Colors.white,))
                                            : const Center(
                                            child: Text(
                                          'Submit',
                                          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                                        )),
                                      ),
                              );
                            }))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
