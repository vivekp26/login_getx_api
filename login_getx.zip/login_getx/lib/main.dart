import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login_getx/app_route/go_router.dart';
import 'package:login_getx/auth_screens/login_screen.dart';
import 'package:login_getx/controller/login_Conrtroller.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Get.put(LoginController());
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      initialRoute: RoutesClas.getLoginRoute(),
      getPages: RoutesClas.routes,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // home: const LoginScreen(),
    );
  }
}

