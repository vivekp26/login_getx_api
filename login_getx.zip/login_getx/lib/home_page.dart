import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:login_getx/app_route/go_router.dart';
import 'package:login_getx/controller/resto_category_controller.dart';
import 'package:login_getx/controller/login_Conrtroller.dart';
import 'package:login_getx/auth_screens/login_screen.dart';
import 'package:login_getx/model/custom_textfield.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final loginController = Get.find<LoginController>();
  final RestoCategoryController restoCategoryController = Get.put(RestoCategoryController());

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', false); // Clear login status
    await Future.delayed(const Duration(seconds: 1));
    loginController.clearFields();
    Fluttertoast.showToast(msg: 'User Logout');
    // Get.offAll(const LoginScreen());
    Get.offAllNamed(RoutesClas.getLoginRoute());
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    restoCategoryController.restoApi();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Align(
            alignment: Alignment.bottomLeft,
            child: SizedBox(
              height: Get.height * 0.08,
              child: FloatingActionButton(
                elevation: 20,
                shape: const CircleBorder(),
                onPressed: () {},
                backgroundColor: Colors.black,
                // hoverColor: Colors.black,
                child: const Icon(Icons.menu_book_outlined, color: Colors.white, size: 30),
              ),
            ),
          ),
        ),
        appBar: AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          title: const Text(
            'Deondy Dairy',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: Colors.blueAccent),
          ),
          actions: [
            IconButton(
                onPressed: () {
                  showDialog(
                    barrierDismissible: false,
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        actions: [
                          Column(
                            children: [
                              const Divider(),
                              TextButton(
                                  onPressed: () {
                                    _logout();
                                  },
                                  child: const Text(
                                    'Log out',
                                    style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold),
                                  )),
                              const Divider(),
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text(
                                    'Cancel',
                                    style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold),
                                  ))
                            ],
                          )
                        ],
                        contentPadding: const EdgeInsets.all(20),
                        title: const Text(
                          'Log out of your account?',
                          style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                      );
                    },
                  );
                },
                icon: const Icon(
                  Icons.logout,
                  color: Colors.black,
                  size: 25,
                )),
          ],
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Divider(),
            Row(
              children: [
                TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Fresh Milk',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                    )),
                TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Fresh Yogurt',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                    )),
                TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Cheese',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                    )),
              ],
            ),
            const Divider(),
            SizedBox(
              height: Get.height * 0.01,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: CustomTextfield(
                filled: true,
                color: Colors.grey.shade300,
                prefixIcon: const Icon(Icons.search_rounded),
                hintText: 'Search Item',
              ),
            ),
            SizedBox(
              height: Get.height * 0.01,
            ),
            const Divider(
              thickness: 3,
            ),
            SizedBox(
              height: Get.height * 0.01,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: SingleChildScrollView(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text(
                      'Category Menu',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
                    ),
                    SizedBox(height: Get.height*0.01,),
                    SizedBox(
                        height: Get.height*0.5,
                        child: Obx(() {
                          return restoCategoryController.resultList.isEmpty
                              ? const Center(child: CircularProgressIndicator())
                              : GridView.builder(
                                  shrinkWrap: true,
                                  scrollDirection: Axis.vertical,
                                  itemCount: restoCategoryController.resultList.length,
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      childAspectRatio: 3 / 5.5, crossAxisCount: 2, mainAxisSpacing: 15, crossAxisSpacing: 15),
                                  itemBuilder: (context, index) {
                                    final item = restoCategoryController.resultList[index];
                                    return Container(
                                      decoration:
                                          BoxDecoration(border: Border.all(color: Colors.grey, width: 2), borderRadius: BorderRadius.circular(15)),
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Center(
                                                child: CachedNetworkImage(
                                                  key: UniqueKey(),
                                                  height: Get.height * 0.1,
                                                  width: Get.width * 0.1,
                                                  imageUrl: item.menuItemDetail?[0].image ?? "",
                                                  fit: BoxFit.cover,
                                                  progressIndicatorBuilder: (context, url, progress) => Center(
                                                      child: CircularProgressIndicator(
                                                        value: progress.progress,
                                                      )),
                                                  filterQuality: FilterQuality.high,
                                                  errorWidget: (context, url, error) => Container(
                                                      decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.circular(10),
                                                          image: const DecorationImage(
                                                            image: NetworkImage(
                                                                'https://tse4.mm.bing.net/th?id=OIP.NlGMwsiUolv9RhubBn2_nwHaFW&pid=Api&P=0&h=180'),
                                                            fit: BoxFit.cover,
                                                            filterQuality: FilterQuality.high,
                                                          ))),
                                                  imageBuilder: (context, imageProvider) => Container(
                                                    height: Get.height * 0.1,
                                                    width: Get.width * 0.1,
                                                    decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                    image: DecorationImage(image: imageProvider, fit: BoxFit.cover)),
                                                  ),
                                                )),
                                            SizedBox(
                                              height: Get.height * 0.01,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 10.0),
                                              child: Center(
                                                  child: Text(
                                                item.menuItemDetail?[0].itemName ?? "",
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
                                              )),
                                            ),
                                            SizedBox(
                                              height: Get.height * 0.01,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 10.0),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(item.menuItemDetail?[0].itemName ?? "",maxLines: 2,softWrap: false,
                                                      style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 16)),
                                                  SizedBox(
                                                    height: Get.height * 0.01,
                                                  ),
                                                  Text('\$ ${item.menuItemDetail?[0].price}',
                                                      style: TextStyle(color: Colors.blueAccent.shade700, fontWeight: FontWeight.bold, fontSize: 15)),
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              height: Get.height * 0.02,
                                            ),
                                            Container(
                                              height: Get.height * 0.04,
                                              width: MediaQuery.of(context).size.width,
                                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.blueAccent.shade700),
                                              child: const Center(
                                                  child: Text(
                                                'Subscribe',
                                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
                                              )),
                                            ),
                                            SizedBox(
                                              height: Get.height * 0.01,
                                            ),
                                            Container(
                                              height: Get.height * 0.04,
                                              width: MediaQuery.of(context).size.width,
                                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.blueAccent.shade700),
                                              child: const Center(
                                                  child: Text(
                                                'ADD',
                                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
                                              )),
                                            ),
                                            SizedBox(
                                              height: Get.height * 0.01,
                                            ),
                                            // Center(child: Text('Customizable',style: TextStyle(fontSize: 15,color: Colors.blueAccent.shade700),))
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                        }))
                  ]),
                ),
              ),
            ),
          ],
        ));
  }
}
